﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ResourceType { NONE, WOOD, STONE, FOOD }
public enum AgentState { WAITING, MOVING, WOODCUTTING, STORING }
public enum GuildState { INACTIVE, ACTIVE }
